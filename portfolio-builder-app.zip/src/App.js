
import React, { useState } from 'react';
import { jsPDF } from 'jspdf';
import Login from './components/Login';
import PortfolioForm from './components/PortfolioForm';
import PortfolioPreview from './components/PortfolioPreview';
import { auth } from './firebase/firebase';

const App = () => {
  const [user, setUser] = useState(null);
  const [portfolioData, setPortfolioData] = useState(null);

  const handleLogout = () => {
    auth.signOut();
    setUser(null);
  };

  const generatePDF = () => {
    const doc = new jsPDF();
    doc.text(`Name: ${portfolioData.name}`, 10, 10);
    doc.text(`Bio: ${portfolioData.bio}`, 10, 20);
    doc.text(`Skills: ${portfolioData.skills}`, 10, 30);
    doc.text(`Projects: ${portfolioData.projects}`, 10, 40);
    doc.save('portfolio.pdf');
  };

  return (
    <div>
      {user ? (
        <div>
          <button onClick={handleLogout}>Logout</button>
          <PortfolioForm setPortfolioData={setPortfolioData} />
          {portfolioData && (
            <>
              <PortfolioPreview portfolioData={portfolioData} />
              <button onClick={generatePDF}>Download as PDF</button>
            </>
          )}
        </div>
      ) : (
        <Login setUser={setUser} />
      )}
    </div>
  );
};

export default App;
