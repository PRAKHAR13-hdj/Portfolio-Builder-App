
import React, { useState } from 'react';

const PortfolioForm = ({ setPortfolioData }) => {
  const [name, setName] = useState('');
  const [bio, setBio] = useState('');
  const [skills, setSkills] = useState('');
  const [projects, setProjects] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setPortfolioData({ name, bio, skills, projects });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Your Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <textarea
        placeholder="About You"
        value={bio}
        onChange={(e) => setBio(e.target.value)}
      />
      <input
        type="text"
        placeholder="Skills (comma-separated)"
        value={skills}
        onChange={(e) => setSkills(e.target.value)}
      />
      <textarea
        placeholder="Projects"
        value={projects}
        onChange={(e) => setProjects(e.target.value)}
      />
      <button type="submit">Save Portfolio</button>
    </form>
  );
};

export default PortfolioForm;
