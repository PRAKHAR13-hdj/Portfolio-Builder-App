
import React from 'react';

const PortfolioPreview = ({ portfolioData }) => {
  return (
    <div>
      <h2>Portfolio Preview</h2>
      <p><strong>Name:</strong> {portfolioData.name}</p>
      <p><strong>Bio:</strong> {portfolioData.bio}</p>
      <p><strong>Skills:</strong> {portfolioData.skills}</p>
      <p><strong>Projects:</strong> {portfolioData.projects}</p>
    </div>
  );
};

export default PortfolioPreview;
